Example.activity
================

A launcher framework for developing pygame/spyral based OLPC XO activities.


Make sure to run the init.py to get started!
