GUI related Sprites and Groups 
##############################

This module implements some elements which are helpful in the creation of guis
or more generally event interaction with sprites. This module is incomplete.

.. automodule:: spyral.gui
   :members:
   :show-inheritance:
