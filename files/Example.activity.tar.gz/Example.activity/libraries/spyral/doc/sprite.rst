Sprites and Groups
##################

.. automodule:: spyral.sprite
   :members:
   :member-order: bysource