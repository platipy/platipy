Point and tuple helper functions
################################

.. automodule:: spyral.point
   :members: