Utility and Helper Functions
############################

.. automodule:: spyral.util
   :members: