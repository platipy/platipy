import spyral._lib.gameclock
import spyral._lib.bezier