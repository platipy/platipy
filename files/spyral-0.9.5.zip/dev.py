import spyral
import os

def _get_spyral_path():
    return os.path.dirname(spyral.__file__) + '/'